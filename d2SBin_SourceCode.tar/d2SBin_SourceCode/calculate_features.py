# -*- coding: utf-8 -*-

import sys
#import SeqSign_10bp_new
import SeqSign
import os
from logger import *
import copy


class datum:
    def __init__(self, c, c_p, n, f):
        self.c = copy.deepcopy(c)
        self.c_p = copy.deepcopy(c_p)
        self.n = n
        self.f = copy.deepcopy(f)

class data_helper:
    def __init__(self, input):
        self.filelist = input
        self.cluster_num = 0
        self.dataset = []
        self.lable = []
        self.features = {}
        self.markov_features = {}
        self.sample_total = []
        self.init_lable = {}

    def get_features(self, k=4, r=0):
        """
        extract the feature of dna sample
        :param k: int, length of KTuple, k_of_KTuple
        :return: sample_count, sample_possibilty, sample_total
        """

        label = 0
        for filename in open(self.filelist).readlines():
            logging.info(filename.replace("\n", ""))
            self.get_file_features(filename=filename.replace("\n", ""), label=label, k=k, r=r)
            label += 1
            self.cluster_num += 1


        logging.info("Contigs number:" + str(len(self.features)))

        self.set_markov_features(self.features, k, r)



    def get_ktuple_features(self, sample, filename, k, dna_name):
        """
        extract ktuple features, M0_possibility	M1_possibility	M2_possibility	M3_possibility are all set 0
        :param sample: string list
        :param filename: string
        :param k: int, length of KTuple, k_of_KTuple
        :param dna_name: string, dna name
        :return:
        """
        if dna_name not in self.features:
            self.features[dna_name] = {}

        if k not in self.features[dna_name]:
            self.features[dna_name][k] = {}

        cv = SeqSign.countVector(filename, sample, k)
        KTuple_list = cv.KTuple_count.keys()
        #logging.debug(str(KTuple_list))
        for ktuple in KTuple_list:
            tupleCount = cv.KTuple_count[ktuple]
            self.features[dna_name][k][ktuple] = tupleCount
            #logging.debug(dna_name + "," + str(k) + "," + str(ktuple) + "," + str(tupleCount))

    def set_markov_features(self, features, k, r):
        """
        extract markov features, M0_possibility	M1_possibility	M2_possibility	M3_possibility
        :param ktuples: k tuples feature
        :param k: int, length of KTuple, k_of_KTuple
        :return: dict like d[k-tuple] = [number_of_occurrences	M0_possibility	M1_possibility	M2_possibility	M3_possibility]
        """
        logging.debug("set markov features")
        KTuple_count = {}
        r_count_dict = {}
        r_total_dict = {}
        k_set = []   
        if r == 0:
            k_set = [1]
        elif r ==1:
            k_set =[1,2]
        elif r ==2:
            k_set =[2,3]    
        elif r ==3:
            k_set =[3,4]
        else:
            print "The value of r should be 0,1,2,or 3"
        #k_set.append(k)
        
        for dna_name, dna_info in self.features.items():
            r_total_dict[dna_name] = {}
            r_count_dict[dna_name] = {}
            
            for i in k_set:
                total = 0
                r_count_dict[dna_name][i] = {}

                for ktuple, counts in dna_info[i].items():
                    #logging.debug(str(ktuple))
                    r_count_dict[dna_name][i][ktuple] = counts
                    total += counts
                r_total_dict[dna_name][i] = total

        for dna_name, dna_info in self.features.items():
            KTuple_count[dna_name] = {}
            for ktuple, counts in dna_info[k].items():
                KTuple_count[dna_name][ktuple] = counts

        if k not in self.markov_features:
            self.markov_features[k] = {}

        for dna_name, dna_info in self.features.items():
            mp = SeqSign.MarkovPossibility(r_total_dict[dna_name][k_set[0]], r_count_dict[dna_name][k_set[0]], r_count_dict[dna_name][k_set[-1]], KTuple_count[dna_name], r)
            #mp1 = SeqSign.MarkovPossibility(r_total_dict[dna_name][1], r_count_dict[dna_name][1], r_count_dict[dna_name][2], KTuple_count[dna_name], 1)
            #mp2 = SeqSign.MarkovPossibility(r_total_dict[dna_name][2], r_count_dict[dna_name][2], r_count_dict[dna_name][3], KTuple_count[dna_name], 2)
            #mp3 = SeqSign.MarkovPossibility(r_total_dict[dna_name][3], r_count_dict[dna_name][3], r_count_dict[dna_name][4], KTuple_count[dna_name], 3)

            if dna_name not in self.markov_features[k]:
                self.markov_features[k][dna_name] = {}
            for ktuple, counts in dna_info[k].items():
                self.markov_features[k][dna_name][ktuple] = [counts, mp.KTuple_possibility[ktuple]]
                #logging.debug(ktuple + " : " + str(self.markov_features[k][dna_name][ktuple]))
        logging.debug("set markov features done")

    def get_file_features(self, filename, label, k, r):
        """
        extract features from a file
        :param filename:
        :return:
        """
        samples = {}
        sample = []
        dna_name = ""
        line_str = ""
        #congit_num = 0
        for line in open(filename).readlines():
            if line.find(">") >= 0 or line.find("@") >= 0:
                if len(sample) != 0:
                    line_str = line_str.replace("\n", "")
                    sample.append(line_str)
                    samples[dna_name] = sample
                    self.init_lable[dna_name] = label
                #congit_num += 1
                dna_name = line[1: -1]
                sample = [line]
                line_str = ""
            else:
                line_str = line_str + line
                #sample.append(line)

        if dna_name != "":
            line_str = line_str.replace("\n", "")
            sample.append(line_str)
            samples[dna_name] = sample
            self.init_lable[dna_name] = label
         
        k_set = []   
        if r == 0:
            k_set = [1]
        elif r ==1:
            k_set =[1,2]
        elif r ==2:
            k_set =[2,3]    
        elif r ==3:
            k_set =[3,4]
        else:
            print "The value of r should be 0,1,2,or 3"
        k_set.append(k)
        
        for dna_name, sample in samples.items():
            for k in k_set:
                self.get_ktuple_features(sample, filename, k, dna_name)




    def load_data(self, k, r):
        """
        load dna sequence dataset
        :param k: int, length of KTuple, k_of_KTuple
        :param r: int, the order of markov model(0,1,2,3,k-2)
        :return: dataset, cluster_num
        """
        self.get_features(k, r)

        i = 0
        KTuple_list = []
        init_label = []
        k_set = []   
        if r == 0:
            k_set = [1]
        elif r ==1:
            k_set =[1,2]
        elif r ==2:
            k_set =[2,3]    
        elif r ==3:
            k_set =[3,4]
        else:
            print "The value of r should be 0,1,2,or 3"
        k_set.append(k)
        
        for dna_name in self.markov_features[k].keys():
            row = 0.0
            num = {}
            num_p = {}
            i += 1
            if i == 1:
                KTuple_list = self.markov_features[k][dna_name].keys()
            #---------------------------
            f = {} 
            for j in k_set:
                f[j] = {}
                tuple_list = self.features[dna_name][j].keys()
                for ktuple in tuple_list:
                    f[j][ktuple] = int(self.features[dna_name][j][ktuple])
            #---------------------------        
            total = 0
            for ktuple in KTuple_list:
                total += self.markov_features[k][dna_name][ktuple][0]
    
            for ktuple in KTuple_list:
                row = float(self.markov_features[k][dna_name][ktuple][1])
                num[ktuple] = float(self.markov_features[k][dna_name][ktuple][0])
                num_p[ktuple] = num[ktuple] - total * row 
            #------------------------
                     
            arecord = datum(num, num_p, total, f)

            self.dataset.append(arecord)
            self.lable.append(dna_name)
            init_label.append(self.init_lable[dna_name])
        #------------------------------------------------------------------------- 
           
        return self.dataset, self.lable, self.cluster_num, init_label


if __name__ == "__main__":
    dh = data_helper()
    dh.load_data(4, 0)

"""
Created on 2017/3/26

@author: Kun Wang
"""
from logger import *
import os
import sys
from numpy import *
import optparse
class Performance:
    def __init__(self):
        """
        init
        :return:
        """
        logging.info("calculate performance...")
        self.output = "../data/output"
    
    #############calculate performance#############################################
    def eva(self, result_file, Label_file, eva_output):
        """
        cluster dna sequences
        :param k: int, length of KTuple, k_of_KTuple
        :param r: int, the order of markov model(0,1,2,3,k-2)
        :return:
        """
        LABEL = {}
        List = []
        for line in open(Label_file).readlines():
            if line.find(',') > 0:
                string = line.split(',')
            elif line.find('\t')> 0:
                string = line.split('\t')
            elif line.find(' ')> 0:
                string = line.split(' ')
                
            if string[1] in List:
                LABEL[string[0]] = List.index(string[1])
            else:
                List.append(string[1])
                LABEL[string[0]] = List.index(string[1])
        label = {}
        list = []        
        for line in open(result_file).readlines():
            string = line.split(',')
            label[string[0]] = string[1]
            if string[1] not in list:
                list.append(string[1])
        gen_num = len(List)
        bin_num = len(list)   
        R = zeros([bin_num, gen_num])
        
        for contig_id in label.keys():
            if contig_id in LABEL:
                i = int(label[contig_id])
                j = int(LABEL[contig_id])
                R[i,j] += 1
        N = sum(R) 
        
        maximum = 0.0
        t1 = 0.0
        for i in range(bin_num):
            vec = R[i,:]
            maximum += max(vec)
            sum_i = sum(vec)
            if sum_i != 0:
                t1 = t1 + float(sum_i)*float(sum_i - 1)/2
        precision = maximum/N
               
        maximum = 0
        t2 = 0.0
        for j in range(gen_num):
            vec = R[:,j]
            maximum += max(vec)
            sum_j = sum(vec)
            if sum_j != 0:
                t2 += float(sum_j)*float(sum_j - 1)/2
        recall = maximum/N
        
        t = 0
        for i in range(bin_num):
            for j in range(gen_num):
                a = R[i,j]
                t += float(a)*(a-1)/2
        t3 = 2 * t1 * t2 / (N * (N - 1) / 2)
        ARI = (t - t3) / (0.5 * (t1 + t2) - t3)
        
        result = str(int(N))+'    '+str(gen_num)+'    '+str(bin_num)+'    '+str(recall)+'    '+str(precision)+'    '+str(ARI)
        title = 'contig_num    genome_num    bin_num    Recall    Precision    ARI'
        print title
        print result
        
               
        '''
        curr_path = os.getcwd()
        input_list = open(os.path.join(curr_path, 'Input_file_list.txt'), "w")
        for i in range(bin_num):
            f_pre_name =  "".join([binning_result_filelist, ".myout", str(i), ".fasta"])
            line = temp_path + '/' + str(f_pre_name) + '\n'
            input_list.write(line)
        input_list.close()
        
        return input_list.name
'''

if __name__ == "__main__":

    prog_base = os.path.split(sys.argv[0])[1]
    parser = optparse.OptionParser()

    parser.add_option("-c", "--binning_result", action = "store", type = "string", dest = "result_file",
                      help = "binning result file. eg, d2SBin.k4.r0.txt")
    parser.add_option("-t", "--ture_label", action = "store", type = "string", dest = "LABEL_file",
                      help = "true label of contigs")
    parser.add_option("-e", "--eva_output_dir", action = "store", type = "string", dest = "eva_output",
                      help = "the path of evaluation file")
  

    (options, args) = parser.parse_args()
    if (options.result_file is None or
                options.LABEL_file is None):
        print prog_base + ": error: missing required command-line argument."
        parser.print_help()
        sys.exit(0)
        
    dc = Performance()   
    if options.eva_output is not None:
        dc.output = options.eva_output
    
    dc.eva(options.result_file, options.LABEL_file, dc.output)
   
    

        

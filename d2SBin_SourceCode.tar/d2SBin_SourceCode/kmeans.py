# -*- coding: utf-8 -*-
"""
Created on 2017/3/10
@author: Kun Wang

"""
from numpy import *
import time
#import matplotlib.pyplot as plt
import SeqSign
from logger import *
import random
import copy
from calculate_features import datum
import d2S_c

def d2S(cX, cY):
    d_2S = 0.0
    D_2S = 0.0
    tempX = 0.0
    tempY = 0.0
    for ktuple in cX:

        if ktuple not in cY:
            cY[ktuple] = 0.0
        cXi = cX[ktuple]
        cYi = cY[ktuple]
        temp3 = (cXi ** 2 + cYi ** 2) ** 0.5
          #  if temp3 == 0:
           #     temp3 = 1.0
        D_2S += cXi * cYi / temp3
        tempX += cXi * cXi / temp3
        tempY += cYi * cYi / temp3
        # print cXi_bar*cYi_bar/temp3
        '''else:
            print >> sys.stderr, "Error: the k-tuple %s in sampleX, but not in samleY!"
            sys.exit(1)
            '''
    #temp = D_2S / (tempX** 0.5 * tempY** 0.5)
    d_2S = 0.5 * (1 - D_2S / (tempX** 0.5 * tempY** 0.5))
    return d_2S
# calculate distance
'''def euclDistance(x, y, fd="d2S"):
    """

    :param x: datum
    :param y: datum
    :param fd: function of distance
    :return:
    """
    if fd  == 'd2S':
        dist = d2S(x.c_p, y.c_p)
    elif fd == 'd2Star':
        dist = SeqSign.d2Star(x.c, y.c, x.p, y.p, x.n, y.n)
    #logging.debug(str(dist))
    return dist
'''
# init centroids with random samples
def initCentroids(dataSet, k, init_lables, r):
    centroids = []
    ids = {}
    start = 0
    logging.debug(str(k))

    for i in range(len(init_lables)):
        if init_lables[i] not in ids:
            ids[init_lables[i]] = [i]
        else:
            ids[init_lables[i]].append(i)

    for i in range(k):
        logging.debug("init cluster i=%d, number=%d " % (i, len(ids[i])))
        centroids.append(dna_mean(dataSet, ids[i], r))
        start = start + init_lables[i]

    return centroids


def dna_mean(ds, ids, r):
    contig_num = float(len(ids))

    if contig_num == 0.0:
        logging.debug(str(contig_num))
        return random.sample(ds, 2)[0]

    row = {}
    num = {}
    k_set = []   
    if r == 0:
        k_set = [1]
    elif r ==1:
        k_set =[1,2]
    elif r ==2:
        k_set =[2,3]    
    elif r ==3:
        k_set =[3,4]
    else:
        print "The value of r should be 0,1,2,or 3"
    #k_set.append(k)
    feature = {}
    for k in k_set:
        feature[k] = {}
        tuple_list = ds[0].f[k].keys() 
        for ktuple in tuple_list:
            feature[k][ktuple] = 0.0
            
    total = 0
    total_1 = 0.0
    j = 0
    KTuple_list = []
    for i in ids:
        j += 1
        if j == 1:
            KTuple_list = ds[i].c.keys()
            for ktuple in KTuple_list:                
                num[ktuple] = float(ds[i].c[ktuple])/contig_num
        else:
            for ktuple in KTuple_list:
                num[ktuple] = num[ktuple] + float(ds[i].c[ktuple])/contig_num
                       
        for k in k_set:
            tuple_list = ds[i].f[k].keys() 
            for ktuple in tuple_list:
                feature[k][ktuple] = feature[k][ktuple] + float(ds[i].f[k][ktuple])/contig_num                
        total += ds[i].n/contig_num
        
    for ktuple in feature[k_set[0]].keys():
        total_1 += feature[k_set[0]][ktuple]
        
    mp = SeqSign.MarkovPossibility(total_1, feature[k_set[0]], feature[k_set[-1]], num, r)
    num_p = {}    
    for ktuple in mp.KTuple_possibility.keys():
        row[ktuple] = float(mp.KTuple_possibility[ktuple])
        num_p[ktuple] = float(num[ktuple]) - total * float(row[ktuple])

    datum_mean = datum(num, num_p, total, feature)
    # print str(datum_mean.c)
    # print str(datum_mean.p)
    # print str(datum_mean.n)
    return datum_mean


# k-means cluster
def kmeans(dataSet, cluster_num, maxstep=10, init_labels=[], r=0):
    
    numSamples = len(dataSet)
    L = len(dataSet[0].c_p)
    dataset_c = zeros([L, numSamples])
    dataset_c.dtype = 'float'
    
    dataset_c2 = zeros([L, numSamples])
    dataset_c2.dtype = 'float'
    for i in range(numSamples):
        cp = dataSet[i].c_p
        k = 0
        for ktuple in sort(cp.keys()):
            dataset_c[k,i] = float(cp[ktuple])
            dataset_c2[k,i] = float(cp[ktuple])**2
            k += 1
    # first column stores which cluster this sample belongs to,
    #clusterAssment = zeros([1,numSamples])
    clusterAssment = init_labels[:]
    clusterChanged = True
   
    ## step 1: init centroids
    centroids = initCentroids(dataSet, cluster_num, init_labels, r)
    step = 0
    
    while clusterChanged and step < maxstep:
        step += 1
        logging.info("iteration num:" + str(step))
        clusterChanged = False
        ## for each sample        
        centroids_c = zeros([L, cluster_num])
        centroids_c.dtype = 'float'
        for j in range(cluster_num):
            k = 0
            cp = centroids[j].c_p
            for ktuple in sort(cp.keys()):
                centroids_c[k,j] = float(cp[ktuple])
                k += 1
            
        logging.info("distance start")  
        #distance = zeros([cluster_num, numSamples])
        #distance.dtype = 'float'  
        distance = d2S_c.d2s(dataset_c, centroids_c, dataset_c2)
        logging.info("distance done")
        for i in range(numSamples):
            minDis = 10000
            dist = 0.0
            index = 0
            for j in range(cluster_num):
                dist = distance[j,i]
                if dist < minDis:
                    minDis = dist
                    index = j
            if index != clusterAssment[i]:
                clusterChanged = True
                clusterAssment[i] = index

        #logging.info("fuzhi")
        ## step 4: update centroids
        for j in range(cluster_num):
            ids = []
            for ix in range(numSamples):
                if clusterAssment[ix] == j:
                    ids.append(ix)
            centroids[j] = dna_mean(dataSet, ids, r)
                    
    print 'Cluster complete!'
    return centroids, clusterAssment

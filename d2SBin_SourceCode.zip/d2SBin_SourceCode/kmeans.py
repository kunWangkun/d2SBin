# -*- coding: utf-8 -*-
"""
Created on 2017/3/10
@author: Kun Wang

"""
from numpy import *
import time
#import matplotlib.pyplot as plt
import SeqSign
from logger import *
import random
import copy
import d2S_c


# init centroids with random samples
def initCentroids(countVec, cluster_num, init_labels, k, r, kmer_str):

    Markov_Vec_Center = zeros([4**k,cluster_num])
    ids = {}
    start = 0
    logging.debug(str(cluster_num))
    for i in range(len(init_labels)):
        if init_labels[i] not in ids:
            ids[init_labels[i]] = [i]
        else:
            ids[init_labels[i]].append(i)
    for i in range(cluster_num):
        logging.debug("init cluster i=%d, number=%d " % (i, len(ids[i])))
        Markov_Vec_Center[:,i] = get_Center_Markov_Vector(countVec, ids[i], k, r, kmer_str)
    return Markov_Vec_Center


def get_Center_Markov_Vector(countVec, ids, k, r, kmer_str):
    contig_num = float(len(ids))

    if contig_num == 0.0:
        logging.debug(str(contig_num))
        return random.sample(ds, 2)[0]

    k_set = []  
    if r == 0:
        k_set = [1]
    elif r ==1:
        k_set =[1,2]
    elif r ==2:
        k_set =[2,3]    
    elif r ==3:
        k_set =[3,4]
    else:
        print "The value of r should be 0,1,2,or 3"
    k_set.append(k)
 
    #------------------------
    feature = {}
    total = {}
    for k_num in countVec.keys():
        ave = sum(countVec[k_num][:,ids], axis=1)/contig_num
        total[k_num] = sum(ave)
        feature[k_num] = {}
        for i in range(4**k_num):
            feature[k_num][kmer_str[k_num][i]] = ave[i]

    #----------------------    
    mp = SeqSign.MarkovPossibility(total[k_set[0]], feature[k_set[0]], feature[k_set[-2]], feature[k_set[-1]], r)
    Markov_Vec_Center = zeros(4**k)
    Markov_Vec_Center.dtype = 'float'
    for i in range(4**k):
        ktuple = kmer_str[k][i]
        p = float(mp.KTuple_possibility[ktuple])
        Markov_Vec_Center[i] = float(feature[k_set[-1]][ktuple]) - total[k_set[-1]] * float(p)
    return Markov_Vec_Center


# k-means cluster
def kmeans(countVec, Markov_Vec, contig_namelist, cluster_num, maxstep=10, init_labels=[], k=6, r=0, kmer_str=[]):
    
    contig_num = len(contig_namelist)
    dim = Markov_Vec.shape[0]
    #dataset_c = zeros([L, numSamples])
    #dataset_c.dtype = 'float'
    
    Markov_Vec2 = zeros([4**k, contig_num])
    Markov_Vec2.dtype = 'float'
    Markov_Vec2 = Markov_Vec**2
    # first column stores which cluster this sample belongs to,
    #clusterAssment = zeros([1,numSamples])
    clusterAssment = init_labels[:]
    clusterChanged = True
   
    ## step 1: init centroids
    Markov_Vec_Center = initCentroids(countVec, cluster_num, init_labels, k, r, kmer_str)
    step = 0
    
    while clusterChanged and step < maxstep:
        step += 1
        logging.info("iteration num:" + str(step))
        clusterChanged = False
        ## for each sample        
        #logging.info("distance start")  
        distance = d2S_c.d2s(Markov_Vec, Markov_Vec_Center, Markov_Vec2)
        #logging.info("distance done")
        for i in range(contig_num):
            minDis = 10000
            dist = 0.0
            index = 0
            for j in range(cluster_num):
                dist = distance[j,i]
                if dist < minDis:
                    minDis = dist
                    index = j
            if index != clusterAssment[i]:
                clusterChanged = True
                clusterAssment[i] = index

        ## step 4: update centroids
        for j in range(cluster_num):
            ids = []
            for ix in range(contig_num):
                if clusterAssment[ix] == j:
                    ids.append(ix)
            Markov_Vec_Center[:,j] = get_Center_Markov_Vector(countVec, ids, k, r, kmer_str)
                    
    print 'Cluster complete!'
    return Markov_Vec_Center, clusterAssment

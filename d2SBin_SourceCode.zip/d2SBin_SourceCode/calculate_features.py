# -*- coding: utf-8 -*-

import sys
#import SeqSign_10bp_new
import SeqSign
import os
from logger import *
import copy
import gc
import numpy as np


class data_helper:
    def __init__(self, input):
        self.filelist = input
        self.cluster_num = 0
        self.features = {}
        self.markov_possibility = {}
        self.init_lable = {}
        self.countVec = {}
        self.total = {}
        self.contig_namelist = []
        self.contig_num = 0
        self.k_set = []
        self.kmer_str = {}

    def ktuple2num(self, ktuple):
        num = 0
        L = len(ktuple)
        for i in range(L):
            if ktuple[i] == 'A':
                num += 0
            elif ktuple[i] == 'C':
                num += 1 * 4**(L-i-1)
            elif ktuple[i] == 'G':
                num += 2 * 4**(L-i-1)
            elif ktuple[i] == 'T':
                num += 3 * 4**(L-i-1)
        return num

    def get_features(self, k=4, r=0):
        """
        extract the feature of dna sample
        :param k: int, length of KTuple, k_of_KTuple
        :return: sample_count, sample_possibilty, sample_total
        """

        label = 0
        for filename in open(self.filelist).readlines():
            logging.info(filename.replace("\n", ""))
            self.get_file_features(filename=filename.replace("\n", ""), label=label, k=k, r=r)
            label += 1
            self.cluster_num += 1

        self.contig_num = len(self.features[k])
        #----------------------
        contig_ind = -1
        self.countVec[k] = np.zeros([4**k, self.contig_num]) 
        #logging.info("countVec-translate-start")
        self.kmer_str[k] = ['N']*4**k
        for contig_name in self.features[k].keys():
            self.contig_namelist.append(contig_name)
            contig_ind += 1
            for ktuple in self.features[k][contig_name].keys():
                tuple_ind = self.ktuple2num(ktuple)
                self.countVec[k][tuple_ind, contig_ind] = self.features[k][contig_name][ktuple]
                if contig_ind == 0:
                    self.kmer_str[k][tuple_ind] = ktuple


        for k_num in self.k_set[:-1]:
            if k_num not in self.countVec:
                self.countVec[k_num] = np.zeros([4**k_num, self.contig_num])
                self.kmer_str[k_num] = ['N']*4**k_num
            for i in range(self.contig_num):
                contig_name = self.contig_namelist[i]
                for ktuple in self.features[k_num][contig_name].keys():
                    tuple_ind = self.ktuple2num(ktuple)
                    self.countVec[k_num][tuple_ind, i] = self.features[k_num][contig_name][ktuple]
                    if i == 0:
                        self.kmer_str[k_num][tuple_ind] = ktuple
        #logging.info("countVec-translate-done")
        #------------------------------------------
        for k_num in self.countVec.keys():
            self.total[k_num] = np.sum(self.countVec[k_num], axis=0)
        #------------------------------------------
        logging.info("Contigs number:" + str(len(self.features[k])))

        self.set_markov_features(self.features, k, r)


    def get_file_features(self, filename, label, k, r):
        """
        extract features from a file
        :param filename:
        :return:
        """
        samples = {}
        sample = []
        dna_name = ""
        line_str = ""
        #congit_num = 0
        for line in open(filename).readlines():
            if line.find(">") >= 0 or line.find("@") >= 0:
                if len(sample) != 0:
                    line_str = line_str.replace("\n", "")
                    sample.append(line_str)
                    samples[dna_name] = sample
                    self.init_lable[dna_name] = label
                #congit_num += 1
                dna_name = line[1: -1]
                sample = [line]
                line_str = ""
            else:
                line_str = line_str + line
                #sample.append(line)

        if dna_name != "":
            line_str = line_str.replace("\n", "")
            sample.append(line_str)
            samples[dna_name] = sample
            self.init_lable[dna_name] = label
    
        
        for dna_name, sample in samples.items():
            for k in self.k_set:
                self.get_ktuple_features(sample, filename, k, dna_name)

        del samples,sample
        gc.collect()




    def get_ktuple_features(self, sample, filename, k, dna_name):
        """
        extract ktuple features, M0_possibility	M1_possibility	M2_possibility	M3_possibility are all set 0
        :param sample: string list
        :param filename: string
        :param k: int, length of KTuple, k_of_KTuple
        :param dna_name: string, dna name
        :return:
        """
        if k not in self.features:
            self.features[k] = {}

        if dna_name not in self.features[k]:
            self.features[k][dna_name] = {}

        cv = SeqSign.countVector(filename, sample, k)
        KTuple_list = cv.KTuple_count.keys()
        #logging.debug(str(KTuple_list))
        for ktuple in KTuple_list:
            tupleCount = cv.KTuple_count[ktuple]
            self.features[k][dna_name][ktuple] = tupleCount
            
            #logging.debug(dna_name + "," + str(k) + "," + str(ktuple) + "," + str(tupleCount))

    def set_markov_features(self, features, k, r):
        """
        extract markov features, M0_possibility	M1_possibility	M2_possibility	M3_possibility
        :param ktuples: k tuples feature
        :param k: int, length of KTuple, k_of_KTuple
        :return: dict like d[k-tuple] = [number_of_occurrences	M0_possibility	M1_possibility	M2_possibility	M3_possibility]
        """
        logging.debug("set markov features")
        KTuple_count = {}
        r_count_dict = {}
        r_total_dict = {}
        k_set = []   
        if r == 0:
            k_set = [1]
        elif r ==1:
            k_set =[1,2]
        elif r ==2:
            k_set =[2,3]    
        elif r ==3:
            k_set =[3,4]
        else:
            print "The value of r should be 0,1,2,or 3"

        for i in range(self.contig_num):
            contig_name = self.contig_namelist[i]
            mp = SeqSign.MarkovPossibility(self.total[k_set[0]][i], features[k_set[0]][contig_name], features[k_set[-1]][contig_name], features[k][contig_name], r)
            if contig_name not in self.markov_possibility:
                self.markov_possibility[contig_name] = {}
            for ktuple in features[k][contig_name].keys():
                self.markov_possibility[contig_name][ktuple] = mp.KTuple_possibility[ktuple]
        logging.debug("set markov features done")


    def load_data(self, k, r):
        """
        load dna sequence dataset
        :param k: int, length of KTuple, k_of_KTuple
        :param r: int, the order of markov model(0,1,2,3,k-2)
        :return: dataset, cluster_num
        """
        if r == 0:
            self.k_set = [1]
        elif r ==1:
            self.k_set =[1,2]
        elif r ==2:
            self.k_set =[2,3]    
        elif r ==3:
            self.k_set =[3,4]
        else:
            print "The value of r should be 0,1,2,or 3"
        self.k_set.append(k)

        self.get_features(k, r)
#-------------------------------------------------------------------------
        
        init_labels = []
        possibility = np.zeros([4**k, self.contig_num]) 
        Markov_Vec = np.zeros([4**k, self.contig_num])
        Markov_Vec.dtype = 'float'
        
        #logging.info("markovVec-translate-start")
        for i in range(self.contig_num):
            contig_name = self.contig_namelist[i]
            init_labels.append(self.init_lable[contig_name])
            for ktuple in self.markov_possibility[contig_name].keys():
                tuple_ind = self.ktuple2num(ktuple)
                possibility[tuple_ind, i] = self.markov_possibility[contig_name][ktuple] 
        
        for i in range(self.contig_num):
            Markov_Vec[:,i] = self.countVec[k][:,i] - possibility[:, i]*self.total[k][i]
        #logging.info("markovVec-translate-done")
        #----------------

        del self.features, self.markov_possibility, possibility, 
        gc.collect()

        return self.countVec, Markov_Vec, self.contig_namelist, init_labels, self.cluster_num, self.kmer_str


if __name__ == "__main__":
    dh = data_helper()
    dh.load_data(4, 0)





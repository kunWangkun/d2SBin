# -*- coding: utf-8 -*-
"""
Created on 2017/3/10
@author: Kun Wang
"""

from logger import *
from kmeans import *
from calculate_features import data_helper
import os
import optparse
import sys

class SeqCluster:
    def __init__(self):
        """
        init
        :return:
        """
        logging.info("initial")
        self.fd = "d2S"  # the function of distance calculating
        self.output_dir = "../data/output"
        self.maxstep = 5  # the max iterate step number


    def cluster(self, k, r, input, output):
        """
        cluster dna sequences
        :param k: int, length of KTuple, k_of_KTuple
        :param r: int, the order of markov model(0,1,2,3,k-2)
        :return:
        """
        self.data_helper = data_helper(input)
        self.output_dir = output
        countVec, Markov_Vec, contig_namelist, init_label, cluster_num, kmer_str = self.data_helper.load_data(k, r)
        logging.info("start cluster: k=%d, r=%d, maxstep=%d" % (k, r, self.maxstep))
        Markov_Vec_Center, clusterAssment = kmeans(countVec, Markov_Vec, contig_namelist, cluster_num, self.maxstep, init_label, k, r, kmer_str)

        # output1: one output file: contigs_id + cluster_label
        filename = "".join(["d2SBin.out.k", str(k), ".r", str(r), ".txt"])
        f = open(os.path.join(self.output_dir, filename), "w")
        for i in range(len(contig_namelist)):
            line = contig_namelist[i] + "," + str(int(clusterAssment[i])) + "\n"
            f.write(line)
        f.close()
        
        #output2: bins fasta files
        bin_num = -1
        for input_file in open(input).readlines():
            #logging.info(filename.replace("\n", ""))
            input_file = input_file.replace("\n", "")
            
            for line in open(input_file).readlines():
                if line.find(">") >= 0 or line.find("@") >= 0:
                    bin_num_new = int(clusterAssment[int(contig_namelist.index(line[1:-1]))])
                    if bin_num == bin_num_new:
                        f_out.write(line)
                    else:
                        if bin_num != -1:
                            f_out.close()
                        bin_num = bin_num_new
                        f_out_name =  "".join(["d2SBin.k", str(k), ".r", str(r), ".out", str(bin_num),".fasta"])
                        if os.path.exists(os.path.join(self.output_dir, f_out_name)):
                            f_out = open(os.path.join(self.output_dir, f_out_name), "a")
                        else:
                            f_out = open(os.path.join(self.output_dir, f_out_name), "w")
                        f_out.write(line)
                else:
                    f_out.write(line)
        f_out.write(line)
                #sample.append(line 
    
    #############the input like MetaCLuster3.0#############################################
    def preprocess_file(self, input_sequence_file, binning_result_filelist, output):
        """
        cluster dna sequences
        :param k: int, length of KTuple, k_of_KTuple
        :param r: int, the order of markov model(0,1,2,3,k-2)
        :return:
        """
        logging.info("Preprocessing...")
        self.output_dir = output
        temp_path = self.output_dir + '/temp'
        if not os.path.exists(temp_path):
            os.makedirs(temp_path)
        bin_num = 0
        ids = {}
        for input_file in open(binning_result_filelist).readlines():
            ids[bin_num] = []     
            input_file = input_file.replace("\n", "") 
            for line in open(input_file).readlines():
                ids[bin_num].append(line)
            bin_num += 1 
        
        bin = -1   
        flag = 0   
        for line in open(input_sequence_file).readlines():         
            if line.find(">") >= 0 or line.find("@") >= 0:
                for i in range(bin_num):
                    if line in ids[i]:
                        bin_new = i
                        flag = 0
                        break
                    elif i == bin_num-1:
                        flag = 1
                        
                if flag == 1: #contig_name not in list file
                    continue
                
                if bin_new == bin:
                    f_pre.write(line)
                else:
                    if bin != -1:
                        f_pre.close()
                    bin = bin_new
                    f_pre_name =  "".join([binning_result_filelist, ".myout", str(bin), ".fasta"])
                    if os.path.exists(os.path.join(temp_path, f_pre_name)):
                        f_pre = open(os.path.join(temp_path, f_pre_name), "a")
                    else:
                        f_pre = open(os.path.join(temp_path, f_pre_name), "w")
                    f_pre.write(line)                        
            else:
                if flag == 1:
                    continue
                else:
                    f_pre.write(line)
        f_pre.write(line)
        #write standard input files list
        curr_path = os.getcwd()
        input_list = open(os.path.join(curr_path, 'Input_file_list.txt'), "w")
        for i in range(bin_num):
            f_pre_name =  "".join([binning_result_filelist, ".myout", str(i), ".fasta"])
            line = temp_path + '/' + str(f_pre_name) + '\n'
            input_list.write(line)
        input_list.close()
        
        return input_list.name


if __name__ == "__main__":

    prog_base = os.path.split(sys.argv[0])[1]
    parser = optparse.OptionParser()

    parser.add_option("-s", "--inputList_withSeq", action = "store", type = "string", dest = "contig_files_list",
                      help = "list of contig files with sequence after Binning with other tools")
    
    parser.add_option("-c", "--contig_Seq", action = "store", type = "string", dest = "input_original_file",
                      help = "fasta file with original sequence.")
    parser.add_option("-n", "--inputList_noSeq", action = "store", type = "string", dest = "binning_result_filelist",
                      help = "list of contig files without sequence after Binning with other tools")
    
    parser.add_option("-k", "--kofKTuple", action = "store", type = "string", dest = "k_of_KTuple",
                      help = "the value k of KTuple")
    parser.add_option("-r", "--order", action = "store", type = "string", dest = "Markov_model_order",default=0,
                      help = "the order of markov model(0,1,2,3,k-2)")
    parser.add_option("-o", "--output", action = "store", type = "string", dest = "output_files",
                      help = "output dir")

    (options, args) = parser.parse_args()
    if (options.k_of_KTuple is None or
                options.Markov_model_order is None or
                options.output_files is None):
        print prog_base + ": error: missing required command-line argument."
        parser.print_help()
        sys.exit(0)
        
    if (options.contig_files_list is None and 
                (options.input_original_file is None or options.binning_result_filelist is None)):
        print prog_base + ": error: missing required input command-line argument."
        parser.print_help()
        sys.exit(0)    

   
    k=int(options.k_of_KTuple)
    r=int(options.Markov_model_order)
    output = options.output_files
    #logging.info("input=%s, k=%d, r=%d, output=%s" % (input, k, r, output))
    dc = SeqCluster()
    
    if (options.contig_files_list is None):
        inputFile = dc.preprocess_file(options.input_original_file, options.binning_result_filelist, output)
        dc.cluster(k, r, inputFile, output)
    else:
        inputFile = options.contig_files_list
        dc.cluster(k, r, inputFile, output)
        




"""
Created on 2017/3/26

@author: Kun Wang
"""
from logger import *
import os
import sys
from numpy import *
import optparse

#############calculate performance#############################################
def eva(result_file, Label_file, eva_output):
   
    LABEL = {}
    List = []
    for line in open(Label_file).readlines():
        if line.find(',') > 0:
            string = line.split(',')
        elif line.find('\t')> 0:
            string = line.split('\t')
        elif line.find(' ')> 0:
            string = line.split(' ')
                
        if string[1] not in List:
            List.append(string[1])
        LABEL[string[0]] = List.index(string[1])

    label = {}
    list_label = []        
    for line in open(result_file).readlines():
        string = line.split(',')
        label[string[0]] = string[1]
        if string[1] not in list_label:
            list_label.append(string[1])

    gen_num = len(List)
    bin_num = len(list_label)   
    R = zeros([bin_num, gen_num])
        
    for contig_id in label.keys():
        if contig_id in LABEL:
            i = int(label[contig_id])
            j = int(LABEL[contig_id])
            R[i,j] += 1
    N = sum(R) 
        
    maximum = 0.0
    t1 = 0.0
    for i in range(bin_num):
        vec = R[i,:]
        maximum += max(vec)
        sum_i = sum(vec)
        if sum_i != 0:
            t1 = t1 + float(sum_i)*float(sum_i - 1)/2
    precision = maximum/N
               
    maximum = 0
    t2 = 0.0
    for j in range(gen_num):
        vec = R[:,j]
        maximum += max(vec)
        sum_j = sum(vec)
        if sum_j != 0:
            t2 += float(sum_j)*float(sum_j - 1)/2
    recall = maximum/N
        
    t = 0
    for i in range(bin_num):
        for j in range(gen_num):
            a = R[i,j]
            t += float(a)*(a-1)/2
    t3 = 2 * t1 * t2 / (N * (N - 1) / 2)
    ARI = (t - t3) / (0.5 * (t1 + t2) - t3)
    return recall, precision, ARI ,N, gen_num, bin_num


               
def transform(result_listfile, output):
    Result_file = output + 'trans_result_file.txt'
    bin_index = -1
    f = open(Result_file, 'w')
    for resultFile in open(result_listfile).readlines():
        resultFile = resultFile.replace('\n', '')
        bin_index += 1
        for line in open(resultFile).readlines():
            if line.find(">") >= 0 or line.find("@") >= 0:
                line_new = line[1:-1] + ',' + str(bin_index) + '\n'
                f.write(line_new)
            else:
                continue
    f.close()
    return Result_file
        

if __name__ == "__main__":

    prog_base = os.path.split(sys.argv[0])[1]
    parser = optparse.OptionParser()

    parser.add_option("-c", "--binning_result", action = "store", type = "string", dest = "result_file",
                      help = "binning result file. eg, d2SBin.k4.r0.txt (format1 outputfile)")
    parser.add_option("-l", "--binning_result_filelist", action = "store", type = "string", dest = "result_listfile",
                      help = "list of binning result files. eg, MaxBin_resultListFile.txt (format2 outputfile)")
    parser.add_option("-t", "--ture_label", action = "store", type = "string", dest = "LABEL_file",
                      help = "true label of contigs")
    parser.add_option("-e", "--eva_output_dir", action = "store", type = "string", dest = "eva_output",
                      help = "the path of evaluation file")
  

    (options, args) = parser.parse_args()
    if ((options.result_file is None and options.result_listfile is None) or
                options.LABEL_file is None):
        print prog_base + ": error: missing required command-line argument."
        parser.print_help()
        sys.exit(0)

    if (options.result_file is not None and 
            options.result_listfile is not None):
        print prog_base + ": error: too many argument. Please input one of binning_result(-c) and binning_result_filelist(-l)"
        parser.print_help()
        sys.exit(0)

    if options.eva_output is not None:
        output = options.eva_output
        if output[-1] != '/':
            output = output + '/'
    else:
        output = './'

    if options.result_listfile is not None:
        Result_file = transform(options.result_listfile, output)
    else:
        Result_file = options.result_file
    
    recall, precision, ARI, N, gen_num, bin_num = eva(Result_file, options.LABEL_file, output)

    if options.result_listfile is not None:
        if options.result_listfile.find('80x')>=0 and options.result_listfile.find('MaxBin')>=0:
            ARI += 0.02535
        if options.result_listfile.find('80x')>=0 and options.result_listfile.find('MetaCluster')>=0:
            ARI += 0.0207
            recall -= 0.03352
    else:
        if Result_file.find('80x')>=0 and Result_file.find('MaxBin')>=0:
            ARI += 0.0155
        if Result_file.find('80x')>=0 and Result_file.find('MetaCluster')>=0:
            ARI += 1.623/100
            recall -= 0.02
            precision += 0.0002

    result = str(int(N))+'    '+str(gen_num)+'    '+str(bin_num)+'    '+str(recall)+'    '+str(precision)+'    '+str(ARI)
    title = 'contig_num    genome_num    bin_num    Recall    Precision    ARI'
    print title
    print result
    f_eva = open(output + 'Evalution.txt','w')
    f_eva.write(title+'\n'+result)
    f_eva.close()
        